package xyz.hbs.huarongdao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HuarongdaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
