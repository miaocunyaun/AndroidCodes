package xyz.hbs.huarongdao.utility;

public class IdentifyCode {


}
